import { useState } from 'react'
import logo from './logo.svg'
import style from './App.css'
import { useEffect } from 'react'

function App(){
  /*const posts=[{
    score:100,title:""  , url:" " , by:"", time:new Date().geiTime ,comments:""
  }]*/
  const [posts,setPosts] = useState ([])
  const basicURL = "https://hacker-news.firebaseio.com/v0/";

  useEffect(()=>{
    fetch(`${basicURL}topstories.json?print=pretty`).then(res => res.json()).then(json=>{
    const list = json.slice(0, 10)
    const posts = Promise.all(list.map(id=>fetch(`${basicURL}item/${id}.json?print=pretty`).then(res => res.json())))
    return posts
    }).then(posts=>setPosts(posts))
  },[])


  return(
    <div className='app'>
    <ul id='ls'>
    {posts.map((post,index) => <li classname="news-list" key={index}> 
    <span className='score'>{post.score}</span>
    <span className='title'>
    < a href={post.url}>{post.title}</ a>
    <span className='host'> {`(${new URL(post.url).host})`} </span>
    </span>
    <br/>
    <span className='mata'>
    <span> by</span>
    < a href='#' className='byAuthor'> {post.by} </ a>
    <span className='time'> {Math.floor( new Date().getTime()/1000)-post.time} seconds ago |</span>
    < a href='#' > {`${Object.getOwnPropertyNames(post).length} comments`} </ a>
    </span>
    </li>)}
     </ul>
    </div>
     )
}

export default App








/*
function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>Hello Vite + React!</p>
        <p>
          <button type="button" onClick={() => setCount((count) => count + 1)}>
            count is: {count}
          </button>
        </p>
        <p>
          Edit <code>App.jsx</code> and save to test HMR updates.
        </p>
        <p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
          {' | '}
          <a
            className="App-link"
            href="https://vitejs.dev/guide/features.html"
            target="_blank"
            rel="noopener noreferrer"
          >
            Vite Docs
          </a>
        </p>
      </header>
    </div>
  )
}

export default App
*/